export default [
  {
    ignores: ['dist']
  },
]
